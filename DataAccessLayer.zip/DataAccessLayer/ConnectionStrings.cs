﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class ConnectionStrings
    {
        //public static string ConStr = @"Data Source=.\SQLEXPRESS; Initial Catalog=Appsoly;Integrated Security=True";

        public static string ConStr = @"Data Source=neptune.odeaweb.com;Network Library=DBMSSOCN;Initial Catalog=appsoly;User ID=appsoly;Password=60hDp5?8k";
    }
}
